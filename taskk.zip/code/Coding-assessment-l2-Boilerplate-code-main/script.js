console.log('====================================');
console.log("Connected");
console.log('====================================');
// script.js
function showProducts(category) {
    // Hide all product cards
    document.querySelectorAll('.product-cards').forEach(cards => cards.style.display = 'none');

    // Show the selected category's product cards
    document.getElementById(`${category}-products`).style.display = 'flex';
}

// Initially, show the Men's products
showProducts('men');
